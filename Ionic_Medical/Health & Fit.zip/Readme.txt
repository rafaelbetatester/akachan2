Thank you for Trusting HybApps
You can read and download documentation and installation steps from 
http://blog.hybapps.com/2019/02/03/how-to-use-hybapps-ionic3-theme-with-your-app/

 